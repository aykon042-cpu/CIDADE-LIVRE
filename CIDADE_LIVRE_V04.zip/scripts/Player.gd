extends CharacterBody3D
var character_name := "DANTE"
var role := 0
var active := true
var special_left := 0.0
var rage_left := 0.0
var cam: Camera3D
func _ready():
    var col = CollisionShape3D.new()
    var shape = CapsuleShape3D.new()
    shape.radius = 0.42
    shape.height = 1.8
    col.shape = shape
    add_child(col)
    var mesh = MeshInstance3D.new()
    var capsule = CapsuleMesh.new()
    capsule.radius = 0.42
    capsule.height = 1.8
    mesh.mesh = capsule
    var colors = [Color(0.18,0.32,0.75),Color(0.12,0.52,0.25),Color(0.65,0.18,0.12)]
    var material = StandardMaterial3D.new()
    material.albedo_color = colors[role]
    mesh.material_override = material
    add_child(mesh)
    var pivot = Node3D.new()
    pivot.position.y = 1.1
    add_child(pivot)
    cam = Camera3D.new()
    cam.position = Vector3(0,2.2,6)
    cam.rotation_degrees.x = -13
    pivot.add_child(cam)
    cam.current = active
    set_physics_process(active)
func set_active(value):
    active = value
    set_physics_process(value)
    if cam: cam.current = value
    visible = true
func special():
    if role == 2:
        rage_left = 8.0
    else:
        special_left = 5.0
        Engine.time_scale = 0.55 if role == 1 else 0.4
func _physics_process(delta):
    if special_left > 0:
        special_left -= delta
        if special_left <= 0: Engine.time_scale = 1.0
    if rage_left > 0: rage_left -= delta
    var x = float(Input.is_key_pressed(KEY_D)) - float(Input.is_key_pressed(KEY_A))
    var z = float(Input.is_key_pressed(KEY_S)) - float(Input.is_key_pressed(KEY_W))
    var dir = Vector3(x,0,z).normalized()
    var max_speed = 9.0 if Input.is_key_pressed(KEY_SHIFT) else 5.5
    velocity.x = move_toward(velocity.x, dir.x*max_speed, 20*delta)
    velocity.z = move_toward(velocity.z, dir.z*max_speed, 20*delta)
    if dir.length() > 0: rotation.y = atan2(-dir.x,-dir.z)
    if not is_on_floor(): velocity.y -= 20*delta
    elif Input.is_key_pressed(KEY_SPACE): velocity.y = 7
    move_and_slide()
