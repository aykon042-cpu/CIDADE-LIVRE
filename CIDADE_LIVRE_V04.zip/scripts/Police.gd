extends CharacterBody3D
var target: Node3D
func _ready():
    var mesh = MeshInstance3D.new()
    var capsule = CapsuleMesh.new()
    capsule.radius = 0.4
    capsule.height = 1.8
    mesh.mesh = capsule
    var m = StandardMaterial3D.new()
    m.albedo_color = Color(0.04,0.12,0.32)
    mesh.material_override = m
    add_child(mesh)
    var col = CollisionShape3D.new()
    var s = CapsuleShape3D.new()
    s.radius = 0.4
    s.height = 1.8
    col.shape = s
    add_child(col)
func _physics_process(delta):
    if not is_instance_valid(target): return
    var d = target.global_position-global_position
    d.y = 0
    if d.length() > 1.5:
        velocity.x = d.normalized().x*4.8
        velocity.z = d.normalized().z*4.8
        look_at(Vector3(target.global_position.x,global_position.y,target.global_position.z))
    else:
        velocity.x = 0
        velocity.z = 0
    velocity.y -= 18*delta
    move_and_slide()
