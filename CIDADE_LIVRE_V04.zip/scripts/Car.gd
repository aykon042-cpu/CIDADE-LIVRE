extends CharacterBody3D
var driver: Node3D
var speed := 0.0
func _ready():
    var body = MeshInstance3D.new()
    var bm = BoxMesh.new()
    bm.size = Vector3(2.1,0.8,4.1)
    body.mesh = bm
    body.position.y = 0.55
    body.material_override = mat(Color(0.08,0.18,0.72))
    add_child(body)
    var cabin = MeshInstance3D.new()
    var cb = BoxMesh.new()
    cb.size = Vector3(1.65,0.7,1.9)
    cabin.mesh = cb
    cabin.position = Vector3(0,1.2,-0.2)
    cabin.material_override = mat(Color(0.07,0.1,0.13))
    add_child(cabin)
    var col = CollisionShape3D.new()
    var shape = BoxShape3D.new()
    shape.size = Vector3(2.2,1.4,4.2)
    col.shape = shape
    col.position.y = 0.7
    add_child(col)
    set_physics_process(false)
func mat(c):
    var m = StandardMaterial3D.new()
    m.albedo_color = c
    return m
func _physics_process(delta):
    var throttle = float(Input.is_key_pressed(KEY_W))-float(Input.is_key_pressed(KEY_S))
    var turn = float(Input.is_key_pressed(KEY_D))-float(Input.is_key_pressed(KEY_A))
    speed = move_toward(speed, throttle*20, (11 if throttle != 0 else 6)*delta)
    rotate_y(-turn*clamp(abs(speed)/12,0,1)*delta*1.8)
    velocity = -global_transform.basis.z*speed
    velocity.y -= 18*delta
    move_and_slide()
