CIDADE LIVRE V0.4 — PROTÓTIPO EXPANDIDO

ABRIR:
1. Extraia o ZIP.
2. Instale Godot 4.3 ou superior.
3. Abra o Godot > Importar > selecione project.godot.
4. Execute com F5.

CONTROLES:
WASD mover/dirigir | SHIFT correr | ESPAÇO pular | TAB trocar personagem
Q habilidade especial | E entrar no carro (próximo dele)

IMPLEMENTADO NESTA BASE:
- Três protagonistas originais com troca por TAB.
- Habilidades especiais iniciais (dois modos de desaceleração e modo de fúria).
- Cidade procedural com ruas, prédios, calçadas, parque e árvores.
- Personagem em terceira pessoa, corrida e pulo.
- Carro dirigível básico.
- Polícia perseguidora inicial e HUD de procurado.
- Marcador de missão e HUD textual.
- Renderizador Compatibility para facilitar testes em dispositivos móveis.

LIMITAÇÕES:
Isto é um protótipo experimental, não um GTA V completo nem um APK.
Não inclui centenas de veículos, campanha cinematográfica, armas completas,
helicópteros funcionais, ragdoll avançado, interiores ou gráficos AAA.
Ainda precisa ser aberto e testado no Godot; ajustes podem ser necessários.
A física do carro é arcade. Controles touch dedicados e exportação Android
ficam para a próxima etapa. Não foi compilado nem validado nesta sessão.
