extends Node3D
const PlayerScript = preload("res://scripts/Player.gd")
const CarScript = preload("res://scripts/Car.gd")
const PoliceScript = preload("res://scripts/Police.gd")
var players: Array[Node3D] = []
var active_index := 0
var car: CharacterBody3D
var wanted := 0
var cash := [2500, 1800, 900]
var police_units: Array[Node3D] = []
var hud: Label
var mission_complete := false

func _ready():
    randomize()
    build_city()
    for i in 3:
        var p = PlayerScript.new()
        p.character_name = ["DANTE", "LUCAS", "RAUL"][i]
        p.role = i
        p.position = Vector3(i * 2.0, 1, 4)
        add_child(p)
        players.append(p)
    car = CarScript.new()
    car.position = Vector3(7, 0.7, 0)
    add_child(car)
    var layer = CanvasLayer.new()
    add_child(layer)
    hud = Label.new()
    hud.position = Vector2(18, 16)
    hud.add_theme_font_size_override("font_size", 18)
    hud.add_theme_color_override("font_color", Color.WHITE)
    layer.add_child(hud)
    set_active(0)

func _process(_delta):
    if Input.is_key_pressed(KEY_TAB) and not _tab_lock:
        _tab_lock = true
        set_active((active_index + 1) % 3)
    if not Input.is_key_pressed(KEY_TAB):
        _tab_lock = false
    if Input.is_key_pressed(KEY_Q) and not _special_lock:
        _special_lock = true
        players[active_index].special()
    if not Input.is_key_pressed(KEY_Q):
        _special_lock = false
    if Input.is_key_pressed(KEY_E) and not _interact_lock:
        _interact_lock = true
        enter_car()
    if not Input.is_key_pressed(KEY_E):
        _interact_lock = false
    if wanted > 0 and police_units.size() < min(wanted, 3):
        spawn_police()
    for cop in police_units:
        if is_instance_valid(cop):
            cop.target = players[active_index]
    hud.text = "CIDADE LIVRE V0.4  |  %s  |  $%d  |  PROCURADO: %s\nWASD mover/dirigir • SHIFT correr • ESPAÇO pular • TAB trocar • Q habilidade • E entrar/sair\nMissão: alcance o marcador amarelo" % [players[active_index].character_name, cash[active_index], "★".repeat(wanted) + "☆".repeat(5-wanted)]

var _tab_lock := false
var _special_lock := false
var _interact_lock := false

func build_city():
    var env_node = WorldEnvironment.new()
    var env = Environment.new()
    env.background_mode = Environment.BG_SKY
    var sky = Sky.new()
    sky.sky_material = ProceduralSkyMaterial.new()
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.65, 0.7, 0.8)
    env.ambient_light_energy = 0.7
    env_node.environment = env
    add_child(env_node)
    var sun = DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -25, 0)
    sun.shadow_enabled = true
    add_child(sun)
    box("Ground", Vector3(0,-0.6,0), Vector3(220,1,220), Color(0.22,0.27,0.24))
    for z in range(-90, 100, 30):
        box("Road", Vector3(0,0,z), Vector3(220,0.12,12), Color(0.07,0.08,0.09))
        box("Sidewalk", Vector3(0,0.08,z+8), Vector3(220,0.25,4), Color(0.5,0.49,0.45))
        box("Sidewalk", Vector3(0,0.08,z-8), Vector3(220,0.25,4), Color(0.5,0.49,0.45))
        for x in range(-100, 110, 18):
            box("LaneMark", Vector3(x,0.08,z), Vector3(7,0.03,0.18), Color(0.9,0.82,0.5))
    for x in range(-90, 100, 30):
        box("CrossRoad", Vector3(x,0.01,0), Vector3(10,0.1,220), Color(0.07,0.08,0.09))
    for x in range(-85, 100, 30):
        for z in range(-85, 100, 30):
            if abs(x) < 20 and abs(z) < 20: continue
            var h = randf_range(8, 25)
            var col = [Color(0.48,0.49,0.52),Color(0.65,0.57,0.46),Color(0.35,0.42,0.48)].pick_random()
            box("Building", Vector3(x,h/2,z), Vector3(randf_range(11,17),h,randf_range(11,17)), col)
            for y in range(3, int(h)-1, 4):
                box("WindowStrip", Vector3(x,y,z-8.6), Vector3(8,0.8,0.08), Color(0.12,0.2,0.28))
    box("Park", Vector3(0,0.02,48), Vector3(48,0.15,22), Color(0.12,0.32,0.15))
    for i in 16:
        var tree = Node3D.new()
        tree.position = Vector3(randf_range(-22,22),0,randf_range(39,57))
        add_child(tree)
        var trunk = MeshInstance3D.new()
        var cyl = CylinderMesh.new()
        cyl.height = 2.4
        trunk.mesh = cyl
        trunk.position.y = 1.2
        trunk.material_override = mat(Color(0.3,0.18,0.1))
        tree.add_child(trunk)
        var crown = MeshInstance3D.new()
        var sphere = SphereMesh.new()
        sphere.radius = 1.5
        crown.mesh = sphere
        crown.position.y = 3
        crown.material_override = mat(Color(0.12,0.35,0.16))
        tree.add_child(crown)
    var marker = MeshInstance3D.new()
    var ring = CylinderMesh.new()
    ring.top_radius = 1.5
    ring.bottom_radius = 1.5
    ring.height = 0.12
    marker.mesh = ring
    marker.position = Vector3(0,0.2,-22)
    marker.material_override = mat(Color(1,0.75,0.05))
    add_child(marker)

func box(n, pos, size, color):
    var b = StaticBody3D.new()
    b.name = n
    b.position = pos
    var mesh = MeshInstance3D.new()
    var bm = BoxMesh.new()
    bm.size = size
    mesh.mesh = bm
    mesh.material_override = mat(color)
    b.add_child(mesh)
    var col = CollisionShape3D.new()
    var shape = BoxShape3D.new()
    shape.size = size
    col.shape = shape
    b.add_child(col)
    add_child(b)

func mat(color):
    var m = StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = 0.85
    return m

func set_active(index):
    active_index = index
    for i in players.size():
        players[i].set_active(i == index)

func enter_car():
    var p = players[active_index]
    if p.global_position.distance_to(car.global_position) < 5:
        car.driver = p
        p.visible = false
        p.set_physics_process(false)
        car.set_physics_process(true)

func spawn_police():
    var cop = PoliceScript.new()
    cop.position = players[active_index].global_position + Vector3(randf_range(-16,16),1,randf_range(-16,16))
    add_child(cop)
    police_units.append(cop)
